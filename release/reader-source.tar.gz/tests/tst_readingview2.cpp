#include <QtTest>
#include <QApplication>
#include <QTemporaryDir>
#include <QFile>
#include <QDragEnterEvent>
#include <QMimeData>
#include <QSignalSpy>
#include <QUrl>
#include <QDropEvent>
#include <QFontMetricsF>
#include <QImage>
#include <QPainter>
#include "app/ReadingView.h"
#include "core/Book.h"

using namespace reader;

class TestReadingView2 : public QObject
{
    Q_OBJECT
private slots:
    void customKeysetTriggersSignals();
    void wheelScrollsByLine();
    void findNextJumpsAndHighlights();
    void jumpToBookProgressWholeBook();
    void ctrlWheelAdjustsAlpha();
    void ctrlShiftWheelSnapsAlpha();
    void translucentBackgroundEnabled();
    void dropLocalFileEmitsPath();
    void findNextWholeBookCrossesChapters();
    void wrappedParagraphRenderingKeepsLineGaps();
    void currentBookProgressReflectsReadingPosition();
    void scrollCrossesChapterBoundary();
    void pageTurnCrossesChapterBoundary();
};

static std::shared_ptr<Book> makeBook(const QTemporaryDir &dir)
{
    const QString path = dir.filePath(QStringLiteral("novel.txt"));
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly))
        return nullptr;
    QString text;
    for (int i = 0; i < 30; ++i) {
        text += QStringLiteral("第%1章 章节\n").arg(i + 1);
        if (i == 5)
            text += QStringLiteral("独一无二的线索词\n");
        text += QStringLiteral("正文内容测试\n").repeated(8);
    }
    f.write(text.toUtf8());
    f.close();
    QString err;
    return Book::create(path, &err);
}

void TestReadingView2::customKeysetTriggersSignals()
{
    QTemporaryDir dir;
    auto book = makeBook(dir);
    QVERIFY(book);
    ReadingView view;
    view.resize(500, 600);
    view.setSettings(DisplaySettings());
    Keyset k;
    k.setShortcut(KeyAction::Search, QKeySequence(QStringLiteral("F6")));
    view.setKeyset(k);
    view.setBook(book);
    QSignalSpy spy(&view, &ReadingView::searchRequested);
    QTest::keyClick(&view, Qt::Key_F6);
    QCOMPARE(spy.count(), 1);
}

void TestReadingView2::wheelScrollsByLine()
{
    QTemporaryDir dir;
    auto book = makeBook(dir);
    QVERIFY(book);
    ReadingView view;
    DisplaySettings s;
    s.font = QFont(QStringLiteral("Noto Sans CJK SC"), 16);
    view.setSettings(s);
    view.setBook(book);
    view.show();
    view.resize(300, 100);
    QVERIFY(view.pageCount() > 1);
    QCOMPARE(view.pixelOffset(), 0.0);
    QWheelEvent wheel(QPointF(10, 10), QPointF(10, 10), QPoint(0, 0), QPoint(0, -120),
                      Qt::NoButton, Qt::NoModifier, Qt::NoScrollPhase, false);
    QApplication::sendEvent(&view, &wheel);
    QVERIFY(view.pixelOffset() > 0.0 || view.currentPage() > 0);
}

void TestReadingView2::findNextJumpsAndHighlights()
{
    QTemporaryDir dir;
    auto book = makeBook(dir);
    QVERIFY(book);
    ReadingView view;
    view.setSettings(DisplaySettings());
    view.setBook(book);
    view.resize(500, 600);
    view.goToChapter(5);
    QVERIFY(view.findNext(QStringLiteral("独一无二的线索词")));
    QVERIFY(view.currentMatchStart() >= 0);
    QCOMPARE(view.currentChapter(), 5);
    const QString text = book->chapterText(5);
    const QPair<int, int> range = view.currentPageCharRange();
    QVERIFY(view.currentMatchStart() >= range.first);
    QVERIFY(view.currentMatchStart() < range.second);
    Q_UNUSED(text);
}

void TestReadingView2::jumpToBookProgressWholeBook()
{
    QTemporaryDir dir;
    auto book = makeBook(dir);
    QVERIFY(book);
    ReadingView view;
    view.setSettings(DisplaySettings());
    view.setBook(book);
    view.resize(500, 600);
    view.jumpToBookProgress(0.0);
    QCOMPARE(view.currentChapter(), 0);
    QCOMPARE(view.currentPage(), 0);
    view.jumpToBookProgress(1.0);
    QCOMPARE(view.currentChapter(), book->chapters().size() - 1);
    view.jumpToBookProgress(0.5);
    QVERIFY(view.currentChapter() > 0);
}

void TestReadingView2::ctrlWheelAdjustsAlpha()
{
    ReadingView view;
    view.setSettings(DisplaySettings());
    QSignalSpy spy(&view, &ReadingView::displaySettingsChanged);
    // Ctrl+滚轮向上：更透明
    QWheelEvent up(QPointF(10, 10), QPointF(10, 10), QPoint(0, 0), QPoint(0, 120),
                   Qt::NoButton, Qt::ControlModifier, Qt::NoScrollPhase, false);
    QApplication::sendEvent(&view, &up);
    QCOMPARE(spy.count(), 1);
    const auto gotUp = spy.last().at(0).value<DisplaySettings>();
    QCOMPARE(gotUp.windowAlpha, 245);
    // Ctrl+滚轮向下：更不透明
    QWheelEvent down(QPointF(10, 10), QPointF(10, 10), QPoint(0, 0), QPoint(0, -120),
                     Qt::NoButton, Qt::ControlModifier, Qt::NoScrollPhase, false);
    QApplication::sendEvent(&view, &down);
    QCOMPARE(spy.count(), 2);
    const auto gotDown = spy.last().at(0).value<DisplaySettings>();
    QCOMPARE(gotDown.windowAlpha, 255);
}

void TestReadingView2::ctrlShiftWheelSnapsAlpha()
{
    ReadingView view;
    view.setSettings(DisplaySettings());
    QSignalSpy spy(&view, &ReadingView::displaySettingsChanged);
    // Ctrl+Shift+滚轮向上：基本全透明
    QWheelEvent up(QPointF(10, 10), QPointF(10, 10), QPoint(0, 0), QPoint(0, 120),
                   Qt::NoButton, Qt::ControlModifier | Qt::ShiftModifier,
                   Qt::NoScrollPhase, false);
    QApplication::sendEvent(&view, &up);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.last().at(0).value<DisplaySettings>().windowAlpha, 0);
    // Ctrl+Shift+滚轮向下：完全不透明
    QWheelEvent down(QPointF(10, 10), QPointF(10, 10), QPoint(0, 0), QPoint(0, -120),
                     Qt::NoButton, Qt::ControlModifier | Qt::ShiftModifier,
                     Qt::NoScrollPhase, false);
    QApplication::sendEvent(&view, &down);
    QCOMPARE(spy.count(), 2);
    QCOMPARE(spy.last().at(0).value<DisplaySettings>().windowAlpha, 255);
}

void TestReadingView2::translucentBackgroundEnabled()
{
    ReadingView view;
    QVERIFY(view.testAttribute(Qt::WA_TranslucentBackground));
}

void TestReadingView2::dropLocalFileEmitsPath()
{
    QTemporaryDir dir;
    const QString path = dir.filePath(QStringLiteral("book.txt"));
    QFile f(path);
    QVERIFY(f.open(QIODevice::WriteOnly));
    f.write("内容\n");
    f.close();

    ReadingView view;
    view.resize(400, 500);
    view.show();
    QSignalSpy spy(&view, &ReadingView::fileDropRequested);
    QMimeData mime;
    mime.setUrls({QUrl::fromLocalFile(path)});
    QDragEnterEvent enter(QPoint(10, 10), Qt::CopyAction, &mime, Qt::LeftButton, Qt::NoModifier);
    QApplication::sendEvent(&view, &enter);
    QDropEvent event(QPointF(10, 10), Qt::CopyAction, &mime, Qt::LeftButton, Qt::NoModifier);
    QApplication::sendEvent(&view, &event);
    QCOMPARE(spy.count(), 1);
    QCOMPARE(spy.takeFirst().at(0).toString(), path);
}

void TestReadingView2::findNextWholeBookCrossesChapters()
{
    QTemporaryDir dir;
    auto book = makeBook(dir);
    QVERIFY(book);
    ReadingView view;
    view.setSettings(DisplaySettings());
    view.setBook(book);
    view.resize(500, 600);
    QVERIFY(!view.findNext(QStringLiteral("独一无二的线索词")));
    view.setSearchWholeBook(true);
    QVERIFY(view.findNext(QStringLiteral("独一无二的线索词")));
    QCOMPARE(view.currentChapter(), 5);
    QVERIFY(view.currentMatchStart() >= 0);
}

void TestReadingView2::wrappedParagraphRenderingKeepsLineGaps()
{
    QTemporaryDir dir;
    const QString path = dir.filePath(QStringLiteral("paragraphs.txt"));
    QFile f(path);
    if (!f.open(QIODevice::WriteOnly))
        QFAIL("cannot create book file");
    const QString line = QStringLiteral("一二三四五六七八九十天地玄黄宇宙洪荒").repeated(12);
    QString text;
    for (int i = 0; i < 4; ++i)
        text += line + QLatin1Char('\n');
    f.write(text.toUtf8());
    f.close();

    QString err;
    auto book = Book::create(path, &err);
    QVERIFY(book);
    ReadingView view;
    DisplaySettings s;
    s.font = QFont(QStringLiteral("Noto Sans CJK SC"), 12);
    s.lineGap = 4;
    s.paragraphGap = 8;
    s.compressBlankLines = true;
    s.wordWrap = true;
    view.setSettings(s);
    view.setBook(book);
    view.resize(360, 220);
    QVERIFY(view.pageCount() > 1);

    const int normalBand = QFontMetricsF(s.font).height();
    int maxBand = 0;
    QImage img(view.size(), QImage::Format_ARGB32);
    for (int pg = 0; pg < view.pageCount(); ++pg) {
        view.goToPage(pg);
        img.fill(Qt::white);
        QPainter painter(&img);
        view.render(&painter);
        painter.end();

        int bandStart = -1;
        for (int y = 0; y < img.height(); ++y) {
            bool ink = false;
            for (int x = 0; x < img.width(); ++x) {
                const QColor c = img.pixelColor(x, y);
                if (c.red() < 128 && c.green() < 128 && c.blue() < 128) {
                    ink = true;
                    break;
                }
            }
            if (ink && bandStart < 0) {
                bandStart = y;
            } else if (!ink && bandStart >= 0) {
                maxBand = qMax(maxBand, y - bandStart);
                bandStart = -1;
            }
        }
        if (bandStart >= 0)
            maxBand = qMax(maxBand, img.height() - bandStart);
    }
    QVERIFY2(maxBand <= normalBand,
             qPrintable(QStringLiteral("overlapping text band: %1 px").arg(maxBand)));
}

void TestReadingView2::scrollCrossesChapterBoundary()
{
    QTemporaryDir dir;
    auto book = makeBook(dir);
    QVERIFY(book);
    ReadingView view;
    DisplaySettings s;
    s.font = QFont(QStringLiteral("Noto Sans CJK SC"), 12);
    view.setSettings(s);
    view.setBook(book);
    view.show();
    view.resize(300, 100);

    const int start = view.currentChapter();
    for (int i = 0; i < 500 && view.currentChapter() == start; ++i)
        view.scrollByPixels(200.0);
    QVERIFY(view.currentChapter() > start);

    const int advanced = view.currentChapter();
    for (int i = 0; i < 500 && view.currentChapter() == advanced; ++i)
        view.scrollByPixels(-200.0);
    QVERIFY(view.currentChapter() < advanced);
}

void TestReadingView2::pageTurnCrossesChapterBoundary()
{
    QTemporaryDir dir;
    auto book = makeBook(dir);
    QVERIFY(book);
    ReadingView view;
    DisplaySettings s;
    s.font = QFont(QStringLiteral("Noto Sans CJK SC"), 12);
    view.setSettings(s);
    view.setBook(book);
    view.show();
    view.resize(300, 100);

    const int start = view.currentChapter();
    for (int i = 0; i < 500 && view.currentChapter() == start; ++i)
        view.pageDown();
    QVERIFY(view.currentChapter() > start);

    const int advanced = view.currentChapter();
    for (int i = 0; i < 500 && view.currentChapter() == advanced; ++i)
        view.pageUp();
    QVERIFY(view.currentChapter() < advanced);
}

void TestReadingView2::currentBookProgressReflectsReadingPosition()
{
    QTemporaryDir dir;
    auto book = makeBook(dir);
    QVERIFY(book);
    ReadingView view;
    view.setSettings(DisplaySettings());
    view.setBook(book);
    view.resize(500, 200);
    QCOMPARE(view.currentBookProgress(), 0.0);
    view.goToChapter(15);
    QVERIFY(view.currentBookProgress() > 0.0);
    QVERIFY(view.currentBookProgress() < 1.0);
}

QTEST_MAIN(TestReadingView2)
#include "tst_readingview2.moc"
